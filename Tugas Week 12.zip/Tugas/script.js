function showImage() {
    var dropdown = document.getElementById("imageDropdown");
    var selectedImage = document.getElementById("selectedImage");
    var alertBox = document.getElementById("alertBox");

    var selectedOption = dropdown.options[dropdown.selectedIndex].value;

    // Set the source of the selected image
    selectedImage.src = "gambar/" + selectedOption + ".jpg";

    // Display alert box with the filename
    alert("Ini Gambar: " + selectedOption + ".jpg");
    alertBox.innerHTML = "Ini Gambar: " + selectedOption + ".jpg";
    alertBox.style.display
}